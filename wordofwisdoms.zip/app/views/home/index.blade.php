@extends('layouts.master')

@section('content')

<h2>Quotations will be here!</h2>

@endsection