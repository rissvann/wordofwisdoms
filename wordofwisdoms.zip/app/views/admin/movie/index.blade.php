@extends('admin.layouts.master')

@section('page-title')
<h3>Movie</h3>
@endsection

@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="grid simple">

			<div class="grid-body no-border"> <br>
				
				<a href="{{ route('admin.movie.create') }}" class="btn btn-primary">Add New Movie</a>
				<hr>
				@if(count($movies) > 0)
				<table class="table table-bordered no-more-tables">
					<thead>
						<tr>
							<th class="text-center">title</th>
							<th class="text-center">Original Poster</th>
							<th class="text-center">Released Date</th>
							<th class="text-center">Action</th>
						</tr>
					</thead>
					<tbody>
						@foreach($movies as $movie)
						<tr>
							<td class="text-center">{{ $movie->id }}</td>
							<td>{{ $movie->movie_name }}</td>
							<td><img src="/uploads/movie/{{ $movie->poster }}" alt=""></td>
							<td class="text-center">	
								{{ Form::open(['route' => ['admin.movie.destroy', $movie->id], 'method' => 'DELETE' ]) }}
									<a href="{{ route('admin.movie.edit', $movie->id) }}" class="btn btn-primary btn-small">Edit</a>
									<button type="submit" class="btn btn-danger btn-small">Delete</button>
								{{ Form::close() }}
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
				@else
					<div class="alert alert-info">
						No records found.
					</div>
				@endif

			</div>
		</div>
	</div>
</div>
@endsection