@extends('admin.layouts.master')

@section('page-title')
<h3>Movie</h3>
@endsection

@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="grid simple">

			<div class="grid-body no-border"> <br>

				<h2>Add New</h2>

				@include('admin.layouts._partials.errors')

				<div class="row">
					<div class="col-md-5">
						{{ Form::open(['route' => 'admin.movie.store', 'method' => 'post', 'files' => true]) }}

							<input type="hidden" name="downloaded_poster" id="m_poster">

							<div class="form-group">
								<label for="" class="control-label">Title</label>
								{{ Form::text('title', null, ['class' => 'form-control', 'id' => 'm_title']) }}
							</div>

							<div class="form-group">
								<label for="">Slug</label>
								{{ Form::textarea('slug', null, ['class' => 'form-control', 'rows' => 4]) }}
							</div>

							<div class="form-group">
								<label for="">Genres</label>
								{{ Form::select('genres[]', $genres, null, ['class' => 'form-control', 'multiple']) }}
							</div>

							<div class="form-group">
								<label for="">Actors</label>
								{{ Form::select('actors[]', $person, null, ['class' => 'form-control', 'multiple']) }}
							</div>

							<div class="form-group">
								<label for="">Directors</label>
								{{ Form::select('directors[]', $person, null, ['class' => 'form-control', 'multiple']) }}
							</div>

							<div class="form-group {{ ($errors->first('movie_name') ? 'has-error' : null) }}">
								<label for="" class="control-label">Tagline</label>
								{{ Form::text('tagline', null, ['class' => 'form-control']) }}
								<span class="help-block">{{ $errors->first('tagline') }}</span>
							</div>

							<div class="form-group">
								<label for="">Description</label>
								{{ Form::textarea('description', null, ['class' => 'form-control', 'id' => 'm_plot']) }}
							</div>

							<div class="form-group">
								<label for="">Released Year</label>
								{{ Form::text('released_year', null, ['class' => 'form-control', 'id' => 'm_released_year']) }}
							</div>

							<div class="form-group">
								<label for="">Released Date</label>
								{{ Form::text('released_date', null, ['class' => 'form-control', 'id' => 'm_released_date']) }}
							</div>

							<div class="form-group">
								<label for="">Original Poster</label>
								{{ Form::file('original_poster', ['class' => 'form-control', 'id' => 'm_poster']) }}
							</div>

							<div class="form-group">
								<button type="submit" class="btn btn-success">Save</button>
							</div>

						{{ Form::close() }}
					</div>

					<div class="col-md-5">
						<div class="form-group">
								<label for="">Source ID</label>
								{{ Form::text('source_id', 'tt2400463', ['class' => 'form-control', 'id' => 'source_id']) }}
							</div>

							<div class="form-group">
							<button class="btn btn-primary btn-get-detail" type="button">Get Detail</button></div>
					</div>
				</div>
				

			</div>
		</div>
	</div>
</div>
@endsection

@section('footer.scripts')
<script>
	$(document).ready(function() {

		$(".btn-get-detail").on('click', function(e) {
			var sourceId = $("#source_id").val();

			$.blockUI();

			setTimeout(function() {
				$.get('http://www.omdbapi.com/?i=' + sourceId, function(response) {
					$("#m_title").val(response.Title);
					$("#m_plot").val(response.Plot);
					$("#m_released_year").val(response.Year);
					$("#m_released_date").val(response.Released);
					$("#m_poster").val(response.Poster);

					$.unblockUI();
				});
			}, 5000);
			
			return false;
		});

	});
</script>
@endsection