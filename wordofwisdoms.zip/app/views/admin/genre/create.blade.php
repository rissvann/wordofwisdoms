@extends('admin.layouts.master')

@section('page-title')
<h3>Genre</h3>
@endsection

@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="grid simple">

			<div class="grid-body no-border"> <br>

				<h2>Add New</h2>

				{{ Form::open(['route' => 'admin.genre.store', 'method' => 'post']) }}

					<div class="form-group">
						<label for="">Title</label>
						<input type="text" name="name" id="name" class="form-control">
					</div>

					<div class="form-group">
						<button type="submit" class="btn btn-success">Save</button>
					</div>

				{{ Form::close() }}

			</div>
		</div>
	</div>
</div>
@endsection