@extends('admin.layouts.master')

@section('page-title')
<h3>Genre</h3>
@endsection

@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="grid simple">

			<div class="grid-body no-border"> <br>

				{{ Form::open(['route' => ['admin.genre.update', $genre->id], 'method' => 'PUT' ]) }}
					<div class="form-group">
						<label for="">Title</label>
						<input type="text" name="name" value="{{ $genre->name }}" id="name" class="form-control">
					</div>

					<button class="btn btn-primary" type="submit">Update</button>
				{{ Form::close() }}

			</div>
		</div>
	</div>
</div>
@endsection