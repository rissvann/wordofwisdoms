@extends('admin.layouts.master')

@section('page-title')
<h3>Genre</h3>
@endsection

@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="grid simple">

			<div class="grid-body no-border"> <br>
				
				<a href="{{ route('admin.genre.create') }}" class="btn btn-primary">Add New Genre</a>
				<table class="table table-bordered no-more-tables">
					<thead>
						<tr>
							<th class="text-center" style="width:12%">ID</th>
							<th class="text-center" style="width:22%">Title</th>
							<th class="text-center" style="width:6%">Action</th>
						</tr>
					</thead>
					<tbody>
						@foreach($genres as $genre)
						<tr>
							<td class="text-center">{{ $genre->id }}</td>
							<td class="text-right">{{ $genre->name }}</td>
							<td class="text-center">	
								{{ Form::open(['route' => ['admin.genre.destroy', $genre->id], 'method' => 'DELETE' ]) }}
									<a href="{{ route('admin.genre.edit', $genre->id) }}" class="btn btn-primary btn-small">Edit</a>
									<button type="submit" class="btn btn-danger btn-small">Delete</button>
								{{ Form::close() }}
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>

			</div>
		</div>
	</div>
</div>
@endsection