@extends('admin.layouts.master')

@section('page-title')
<h3>Person</h3>
@endsection

@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="grid simple">

			<div class="grid-body no-border"> <br>
				
				<a href="{{ route('admin.person.create') }}" class="btn btn-primary">Add New Person</a>
				<hr>
				@if(count($people) > 0)
				<table class="table table-bordered no-more-tables">
					<thead>
						<tr>
							<th class="text-center">ID</th>
							<th class="text-center">Person Name</th>
							<th class="text-center">Date of Birth</th>
							<th class="text-center">Action</th>
						</tr>
					</thead>
					<tbody>
						@foreach($people as $person)
						<tr>
							<td class="text-center">{{ $person->id }}</td>
							<td>{{ $person->person_name }}</td>
							<td>{{ $person->birth_date }}</td>
							<td class="text-center">	
								{{ Form::open(['route' => ['admin.person.destroy', $person->id], 'method' => 'DELETE' ]) }}
									<a href="{{ route('admin.person.edit', $person->id) }}" class="btn btn-primary btn-small">Edit</a>
									<button type="submit" class="btn btn-danger btn-small">Delete</button>
								{{ Form::close() }}
							</td>
						</tr>
						@endforeach
					</tbody>
				</table>
				@else
					<div class="alert alert-info">
						No record(s) found.
					</div>
				@endif

			</div>
		</div>
	</div>
</div>
@endsection