@extends('admin.layouts.master')

@section('page-title')
<h3>Person</h3>
@endsection

@section('content')
<div class="row">
	<div class="col-md-12">
		<div class="grid simple">

			<div class="grid-body no-border"> <br>

				<h2>Edit Person</h2>

				@include('admin.layouts._partials.errors')

				<div class="row">
					<div class="col-md-5">
						{{ Form::open(['route' => ['admin.person.update', $person->id], 'method' => 'put', 'files' => true]) }}

							<div class="form-group {{ ($errors->first('person_name') ? 'has-error' : null) }}">
								<label for="" class="control-label">Person Name</label>
								{{ Form::text('person_name', $person->person_name, ['class' => 'form-control']) }}
								<span class="help-block">{{ $errors->first('person_name') }}</span>
							</div>

							<div class="form-group">
								<label for="" class="control-label">Fullname</label>
								{{ Form::text('fullname', $person->fullname, ['class' => 'form-control']) }}
							</div>

							<div class="form-group">
								<label for="">Biography</label>
								{{ Form::textarea('bio', $person->bio, ['class' => 'form-control', 'rows' => 4]) }}
							</div>

							<div class="form-group">
								<label for="">Birth Date</label>
								{{ Form::text('birth_date', $person->birth_date, ['class' => 'form-control']) }}
							</div>

							<div class="form-group">
								<label for="">Birth Place</label>
								{{ Form::text('birth_place', $person->birth_place, ['class' => 'form-control']) }}
							</div>

							<div class="form-group">
								<label for="">Death Date</label>
								{{ Form::text('death_date', $person->death_date, ['class' => 'form-control']) }}
							</div>

							<div class="form-group">
								<label for="">Death Place</label>
								{{ Form::text('death_place', $person->death_place, ['class' => 'form-control']) }}
							</div>

							<div class="form-group">
								<label for="">Original Poster</label>
								{{ Form::file('original_poster', ['class' => 'form-control']) }}
							</div>

							<div class="form-group">
								<label for="">Source ID</label>
								{{ Form::text('source_id', $person->source_id, ['class' => 'form-control']) }}
							</div>

							<div class="form-group">
								<button type="submit" class="btn btn-success">Update</button>
							</div>

						{{ Form::close() }}
					</div>
				</div>
				

			</div>
		</div>
	</div>
</div>
@endsection