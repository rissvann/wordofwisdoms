@if(Session::has('error'))
<p>{{ Session::get('error') }}</p>
@endif
<form action="{{ action('RemindersController@postReset') }}" method="POST">
<pre>
    <input type="hidden" name="token" value="{{ $token }}">
    Email:
    <input type="email" name="email">

    New Password:
    <input type="password" name="password">

    Retype New Password:
    <input type="password" name="password_confirmation">

    <input type="submit" value="Reset Password">
</pre>
</form>