@extends('admin.layouts.master')

@section('page-title')
	<h3>Main Page</h3>
@endsection

@section('content')
	<h1>Hello world</h1>
@endsection
