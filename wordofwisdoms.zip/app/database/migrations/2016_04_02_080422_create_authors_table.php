<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAuthorsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('authors', function(Blueprint $table){
			$table->increments('id');
			$table->string('title')->nullable();
			$table->string('name');
			$table->date('yearofbirth')->nullable();
			$table->date('yearofdeath')->nullable();
			$table->string('placeofbirth')->nullable();
			$table->string('nationality')->nullable();
			$table->integer('profile_id')->unsigned()->index();
			$table->timestamps();

			$table->foreign('profile_id')->references('id')->on('profiles');

		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('authors');
	}

}
