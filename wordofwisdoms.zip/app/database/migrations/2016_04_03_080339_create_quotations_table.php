<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateQuotationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('quotations', function(Blueprint $table){
			$table->increments('id');
			$table->text('quotation');
			$table->integer('author_id')->unsigned()->index();
			$table->integer('language_id')->unsigned()->index();
			$table->integer('source_id')->unsigned()->index();
			$table->integer('translation_id')->unsigned()->index();
			$table->integer('category_id')->unsigned()->index();
			$table->integer('profile_id')->unsigned()->index();
			$table->string('keywords')->nullable();
			$table->integer('hit_counter');
			$table->timestamps();

			$table->foreign('author_id')->references('id')->on('authors');
			$table->foreign('language_id')->references('id')->on('languages');
			$table->foreign('source_id')->references('id')->on('sources');
			$table->foreign('translation_id')->references('id')->on('translations');
			$table->foreign('profile_id')->references('id')->on('profiles');
			$table->foreign('category_id')->references('id')->on('categories');


		});	
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('quotations');
	}

}
