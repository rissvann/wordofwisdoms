<?php

class AdminAuthController extends \BaseController {

	public function getLogin()
	{
		/*if(Auth::viaRemember())
		{
			return Redirect::to('/admin');
		}*/

		return View::make("admin.auth.login");
	}

	public function postLogin()
	{
		if(Auth::attempt(['email' => Input::get('email'), 'password' => Input::get('password')], 
			Input::get('remember_me')))
		{
			return Redirect::intended('/admin');
		}

		return Redirect::back();
	}

	public function getRegister()
	{
		return User::create([
			'name' => 'Administrator',
			'email' => 'admin@admin.com',
			'password' => Hash::make('abc123')
		]);
	}

	public function getLogout()
	{
		Auth::logout();

		return Redirect::to('/admin/auth/login');
	}


}
